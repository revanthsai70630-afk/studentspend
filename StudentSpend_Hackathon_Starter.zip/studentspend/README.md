# StudentSpend — Student Budget Planner

StudentSpend is a responsive personal-finance dashboard designed to help students record income and expenses, set a monthly spending limit, review trends, and track a savings goal.

## Features
- Add, filter, and delete income/expense transactions
- Monthly dashboard totals and budget-left calculation
- Six-month income/expense visualisation
- Category spending overview
- Editable monthly budget and savings goal
- Export transactions as CSV
- Local browser storage; no account or backend required
- Responsive layout for mobile and desktop

## Run locally
Open `index.html` in a modern browser. No build tools or dependencies are required.

## Deploy free with GitHub Pages
1. Create a public repository on GitHub named `studentspend`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. Test the public URL in a private/incognito browser.

Alternative: import the repository into Netlify and deploy the static site.

## Data and privacy
Transactions are stored locally in the browser on the device used. They are not synced across devices. Clearing browser storage can remove saved data. The starter includes illustrative demo transactions; use **Reset demo** before presenting if you want a blank dashboard.

## Hackathon originality
This is a starter implementation. Review, understand, customize, test, and make meaningful changes before submitting it as your own work. Add a feature that reflects a real student need and describe your own contribution honestly.
